#pragma once

#include_next <halconf.h>

/*按需使能外设，无需则留空*/