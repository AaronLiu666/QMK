#pragma once

#include_next <mcuconf.h>

/*按需使能外设，无需则留空*/