#pragma once

#define SOLENOID_PIN B9